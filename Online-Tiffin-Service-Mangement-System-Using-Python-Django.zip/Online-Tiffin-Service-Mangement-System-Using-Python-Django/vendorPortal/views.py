# views.py
from django.shortcuts import render, redirect
from django.contrib import messages
import uuid
from .models import Vendor
from customers.models import Customer
from .forms import VendorLoginForm

def indexVendor(request, id):
    try:
        vendor = Vendor.objects.get(Vendor_Id=id)
        customer_ids = [int(pk) for pk in vendor.Customers_Delivering.split(',') if pk]
        customers = Customer.objects.filter(pk__in=customer_ids)
        
        context = {
            'name': vendor.Vendor_Name,
            'customers': customers,
            'vendor_id': id
        }
        return render(request, "vendorPortal/index.html", context)
    
    except Vendor.DoesNotExist:
        messages.error(request, "Vendor not found")
        return redirect('VendorLogin')

def vendorLogin(request):
    if request.method == "POST":
        form = VendorLoginForm(request.POST)
        if form.is_valid():
            vendor_id = form.cleaned_data['Vendor_ID']
            try:
                vendor = Vendor.objects.get(Vendor_Id=vendor_id)
                return redirect('IndexVendor', id=vendor_id)
            except Vendor.DoesNotExist:
                messages.error(request, "Invalid Vendor ID. Please try again.")
        else:
            messages.error(request, "Invalid form submission")
    else:
        form = VendorLoginForm()
    
    return render(request, "vendorPortal/login.html", {'form': form})

def vendorRegistration(request):
    if request.method == "POST":
        vendor_name = request.POST.get('vendor_name')
        if vendor_name:
            # Generate 8-character unique vendor ID
            vendor_id = str(uuid.uuid4())[:8]
            
            # Create new vendor
            Vendor.objects.create(
                Vendor_Id=vendor_id,
                Vendor_Name=vendor_name,
                Customers_Delivering=""
            )
            
            messages.success(request, f"Registration successful! Your Vendor ID is: {vendor_id}")
            return redirect('VendorLogin')
        else:
            messages.error(request, "Please enter a valid vendor name")
    
    return render(request, "vendorPortal/register.html")