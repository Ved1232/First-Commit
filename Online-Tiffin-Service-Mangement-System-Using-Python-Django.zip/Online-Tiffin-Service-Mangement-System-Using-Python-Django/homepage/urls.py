from django.contrib import admin
from django.urls import path, include
from . import views
urlpatterns = [
     path('admin/', admin.site.urls),
     path("register/", views.registerUser, name="register" ),
    path("", views.index, name="login"),
    path('loggedin/', views.loggedIn, name="loggedin" ),
    path('logout/', views.logoutUser, name="logout" ),
    path('profile/', views.profile, name="profile"),
    # path('feedback/', views.feedback, name="feedback" )
    
]
